﻿public class PlayerData{
	//金币
	public int coin = 0;
	//记事本
	public string text = "new text";
}